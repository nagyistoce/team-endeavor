/*
 *  shuriken.h - Connor Ledgerwood
 *
 *  Provides aliases for pin assignments
 *
*/

/****************************************
 *   
 *              Constants
 *    
 ****************************************/

#define STRENGTH_GAUGE_LATENCY 1    // 100ms at Fosc=8MHz and 1:1 prescale
#define COOLDOWN 61                 // 2s at Fosc=8MHz and 1:8 prescale
#define MAX_AMMO 5

#define NUM_OVF_START	7		// 4ms Start of Data signal
#define NUM_OVF_ZERO	2		// 1ms OFF signal for logic Zero
#define NUM_OVF_ONE		3		// 2ms OFF signal for logic One
#define NUM_OVF_ON		1		// 0.5ms ON signal 

#define NUM_AXIS_DATA 10
#define X 0x04
#define Y 0x02
#define Z 0x01

/****************************************
 *   
 *             Bitmasks
 *    
 ****************************************/

#define  ACC_INT   PORTDbits.RD0
#define  CHIP_SEL  PORTCbits.RC2

#define	 AUD_1  PORTEbits.RE1
#define	 AUD_2  PORTEbits.RE0
#define	 AUD_3  PORTAbits.RA5
#define	 AUD_4  PORTAbits.RA4

#define  READY   PORTBbits.RB4
#define  RELOAD  PORTCbits.RC0

#define  IR_SEL_LO  PORTBbits.RB0
#define  IR_SEL_HI  PORTBbits.RB1
#define  IR_RX      PORTBbits.RB2
#define  IR_TX     	PORTBbits.RB3

#define  SEGMENT  0xF0  //RD 4:7
#define	 STREN	  0x0F  //RA 0:3

#define  DUMB1  PORTDbits.RD1
#define  DUMB2  PORTDbits.RD2
#define  DUMB3  PORTDbits.RD3
#define  DUMB4  PORTCbits.RC1
#define  DUMB5  PORTEbits.RE2

/****************************************
 *   
 *                Function
 *        Definitions & Prototypes
 *    
 ****************************************/

//Initialization routines
extern void init_all();
extern void init_port_directions();
extern void init_oscillator();
extern void init_SPI();
extern void init_UART();
extern void init_interrupts();
extern void init_timers();
extern void init_PWM();
extern void init_accelerometer();
// UART routines
extern void UART_tx(char);
extern void UART_tx_str(char message[50]);
extern void UART_rx();
// Accelerometer routines
extern void acc_config(char, char);
extern char acc_read(char);
extern void monitor_interrupt();
extern void grab_axis(char);
extern int  find_maximum(int*);
extern void bad_motion();
// IR Receive routines
extern void start_of_data();
extern void read_data();
extern void dataDecode();
extern void end_of_data();
extern void array_shift();
// IR Transmit routines
extern void determine_str();
extern void encode_data();
extern void start_tx();
extern void IR_tx_0();
extern void IR_tx_1();
extern void end_tx();
extern void timer2_init();
// Ammo and cooldown routines
extern void update_strength_gauge();
extern void update_cooldown();
extern void update_ammo(char);
// Auxilliary routines
extern void delay_ms(int);
extern void display_decimal(int);
// Test routines
extern void test_cooldown();
extern void test_UART();
extern void test_SPI();
extern void test_accelerometer();
extern void test_throw_strength();
// Interrupt routines
extern void InterruptServiceHigh();
extern void InterruptServiceLow();

//Initialization routines
void init_all();
void init_port_directions();
void init_oscillator();
void init_SPI();
void init_SPI_std();
void init_UART();
void init_interrupts();
void init_timers();
void init_PWM();
void init_accelerometer();
// UART routines
void UART_tx(char);                  //works
void UART_tx_str(char message[50]);  //works
void UART_rx();                      //works
// Accelerometer routines
void acc_config(char, char);         //
char acc_read(char);                 //
void monitor_interrupt();            //
void grab_axis(char);                //
int  find_maximum(int*);             //
void bad_motion();                   //
// IR Receive routines
void start_of_data();                //
void read_data();                //
void dataDecode();                   //
void end_of_data();                  //
void array_shift();                  //
// IR Transmit routines
void determine_str();                //
void encode_data();                  //
void start_tx();                     //
void IR_tx_0();                      //
void IR_tx_1();                      //
void end_tx();                       //
// Ammo and cooldown routines
void update_strength_gauge();        //works
void update_cooldown();              //works
void update_ammo(char);              //works
// Auxilliary routines
void delay_ms(int);                  //works
void display_decimal(int);           //works
// Test routines
void test_cooldown();                //works
void test_UART();                    //works
void test_SPI();                     //works
void test_throw_strength();          //works
void test_accelerometer();           //
// Interrupt routines
void InterruptServiceHigh();         //
void InterruptServiceLow();          //works


extern void convert_readings();
void convert_readings();
extern void display_hex();
void display_hex();
extern void display_ratio();
void display_ratio();

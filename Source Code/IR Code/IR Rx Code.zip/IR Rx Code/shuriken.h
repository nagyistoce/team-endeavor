/*
 *  shuriken.h - Connor Ledgerwood
 *
 *  Provides aliases for pin assignments
 *
*/

#define  ACC_INT   PORTDbits.RD0
#define  CHIP_SEL  PORTCbits.RC2

#define	 AUD_1  PORTEbits.RE1
#define	 AUD_2  PORTEbits.RE0
#define	 AUD_3  PORTEbits.RA5
#define	 AUD_4  PORTEbits.RA4

#define  READY   PORTBbits.RB4
#define  RELOAD  PORTCbits.RC0

#define IR_RX    PORTBbits.RB2

#define	 IR_SEL   0x03  //RB 0:1
#define  SEGMENT  0xF0  //RD 4:7
#define	 STREN	  0x0F  //RA 0:3

#define  DUMB1  PORTDbits.RD1
#define  DUMB2  PORTDbits.RD2
#define  DUMB3  PORTDbits.RD3
#define  DUMB4  PORTCbits.RC1
#define  DUMB5  PORTEbits.RE2
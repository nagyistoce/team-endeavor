#include "p18F4520.h"
#include "shuriken.h"
#include "adxl345.h"
#include <string.h>
#include <spi.h>

#define STRENGTH_GAUGE_LATENCY 1    // 100ms at Fosc=8MHz and 1:1 prescale
#define COOLDOWN 61                 // 2s at Fosc=8MHz and 1:8 prescale
#define MAX_AMMO 5

#define NUM_AXIS_DATA 10
#define X 0x04
#define Y 0x02
#define Z 0x01

/****************************************
 *   
 *                Global
 *               Variables
 *    
 ****************************************/

// Timer overflow variables
char t1_ovf_att = 0;     //For attack cooldown
char t1_ovf_rld = 0;     //For reload cooldown
char t3_ovf = 0;         //For strength gauge tracking

// Attack variables
char action = 0;     //records the state of reload switch upon motion
char att_rdy = 1;
char rld_rdy = 1;
char current_ammo = MAX_AMMO;
char att_strength = 0;

// Visual variables
char gauge_index = 0;
char LED_toggle = 0;

// Accelerometer variables
int X_axis[NUM_AXIS_DATA];
int Y_axis[NUM_AXIS_DATA];
int Z_axis[NUM_AXIS_DATA];

// Serial comm. variables
char didReceive_uart = 0;
char uart_rx_data = 0;
char spi_rx_data = 'q';

/****************************************
 *   
 *                Function
 *        Definitions & Prototypes
 *    
 ****************************************/

//Initialization routines
extern void init_all();
extern void init_port_directions();
extern void init_oscillator();
extern void init_SPI();
extern void init_SPI_std();
extern void init_UART();
extern void init_interrupts();
extern void init_timers();
extern void init_PWM();
extern void init_accelerometer();
// Serial routines
extern void UART_tx(char);
extern void UART_tx_str(char message[50]);
extern void UART_rx();
extern void SPI_tx(char);
// Accelerometer routines
extern void acc_config(char, char);
extern char acc_read(char);
extern void monitor_interrupt();
extern void grab_axis(char);
extern int  find_maximum(int*);
extern void bad_motion();
// Ammo and cooldown routines
extern void update_strength_gauge();
extern void update_cooldown();
extern void update_ammo(char);
// Auxilliary routines
extern void delay_ms(int);
extern void pause();
extern void display_decimal(int);
// Test routines
extern void test_cooldown();
extern void test_UART();
extern void test_SPI();
extern void test_accelerometer();
extern void test_throw_strength();
// Interrupt routines
extern void InterruptServiceHigh();
extern void InterruptServiceLow();

//Initialization routines
void init_all();
void init_port_directions();
void init_oscillator();
void init_SPI();
void init_SPI_std();
void init_UART();
void init_interrupts();
void init_timers();
void init_PWM();
void init_accelerometer();
// Accelerometer routines
void acc_config(char, char);         //
char acc_read(char);                 //
void monitor_interrupt();            //
void grab_axis(char);                //
int  find_maximum(int*);             //
void bad_motion();                   //
// Serial routines
void UART_tx(char);                  //works
void UART_tx_str(char message[50]);  //works
void UART_rx();                      //works
void SPI_tx(char);                   //works
// Ammo and cooldown routines
void update_strength_gauge();        //works
void update_cooldown();              //works
void update_ammo(char);              //works
// Auxilliary routines
void delay_ms(int);                  //works
void pause();                        //works
void display_decimal(int);           //works
// Test routines
void test_cooldown();                //works
void test_UART();                    //works
void test_SPI();                     //works
void test_accelerometer();           //
void test_throw_strength();          //works
// Interrupt routines
void InterruptServiceHigh();         //
void InterruptServiceLow();          //works

/****************************************
 *   
 *                 Main
 *               Routine
 *   
 ****************************************/

void main() {
   init_all();

   //test_throw_strength();
   //test_SPI();
   //test_UART();
   //test_cooldown();
   test_accelerometer();

   //-->  Main program loop
   while(1) {
      if( RELOAD==1 )
         action = 0;
      else
         action = 1;
     monitor_interrupt();
   }
}

/****************************************
 *   
 *         Accelerometer Diagnostic
 *                Routines
 *   
 ****************************************/

/*
 *  Polls the accelerometer's interrupt pin.  If it detects a signal,
 *  it reads the axes involved in the motion.  It then results in a 
 *  bad_motion() or reads more data  from grab_axis()
*/
void monitor_interrupt() {
   int i;
   if( ACC_INT == 1 ) {
      // Read axis that triggered interrupt, determine proper motion
      acc_read(ACT_TAP_STATUS);
      // Executed if reload switch was not pressed for the motion
      if (action==1) {
         if ( spi_rx_data&Z )
            bad_motion();
         else {
            if(spi_rx_data & X)
               grab_axis(DATAX0);
            if (spi_rx_data & Y)
               grab_axis(DATAY0);
         }
      }
      // Executed if reload switch was pressed for the motion
      else if (action==0) {
         if( (spi_rx_data&X) && (spi_rx_data&Y) )
            bad_motion();
         else {
            update_ammo(1);
         }
      }
   }
}

/*
 *  Loads the FIFO data from an axis into the appropriate data
 *  array.  Calls find_maximum()
*/
void grab_axis(char reg) {
   int i;
   char reg_lo = reg;
   char reg_hi = reg + 1;
   int * axis;
   // Set axis data array pointer
   if (reg == DATAX0)
      axis = X_axis;
   else if (reg == DATAY0)
      axis = Y_axis;
   else if (reg == DATAZ0)
      axis = Z_axis;
   // Read in both bytes and lose the two LSBs and stores
   for( i=0 ; i<NUM_AXIS_DATA ; i++) {
      reg_lo = acc_read(reg_lo);
      reg_hi = acc_read(reg_hi);
      reg_lo = reg_lo >> 2;
      reg_hi = reg_hi >> 6;
      axis[i] = reg_hi + reg_lo;
      i++;
   }
   i = 0;
   find_maximum(axis);
}

/*
 *  Analyzes data retrieved from axis to find the sample of
 *  largest magnitude.  Sets a throw strength based on that ratio
*/
int find_maximum(int * axis) {
   int i;
   int min = 0;
   int max = 0;
   float ratio = 0;
   // Find the largest magnitude
   for( i=0 ; i<NUM_AXIS_DATA ; i++ ) {
      if( axis[i] < min )
         min = axis[i];
      if( axis[i] > max )
         max = axis[i];
   }
   if ( max<=0 && min<=0 )
      max = ~min + 1;
   // Set attack strength
   ratio = ((float)max)/255;
   if( ratio < .25 )
      att_strength = 1;
   else if( ratio < .5 )
      att_strength = 2;
   else if( ratio < .75 )
      att_strength = 3;
   else
      att_strength = 4;
   //***** AAAATTTTAAAAACKKKKKKK with IR
   return max;
}

void bad_motion() {
   action = 0;
   att_strength = 0;
   gauge_index = 0;
   //***** OUTPUT BAD SOUND
}

void test_throw_strength() {
   int X_dat[10] = { 19, 30, 43, 64, 112, 153, 92, 31, 21, 12 };
   int Y_dat[10] = { -37, -22, -81, -19, -250, -200, -199, -40, -1, -88 };
   int i;
   int axis_max;
   char request[9] = "Input:  ";
   char axis_message[13] = "Axis data:  ";
   char max_message[16] = "Axis maximum:  ";
   char str_message[18] = "Throw strength:  ";
   char ammo_message[8] = "Ammo:  ";

   uart_rx_data = -1;
   update_ammo(0);
   while (1) {
      //Get input in ASCII x or y
      UART_tx_str(request);
      while( uart_rx_data == -1 ) ;
      UART_tx('\r');
      //Display axis data
      if( uart_rx_data == 'x' ) {
         UART_tx_str(axis_message);
         for(i=0 ; i<10 ; i++)
            display_decimal(X_dat[i]);
         axis_max = find_maximum(X_dat);
         UART_tx('\r');
         UART_tx_str(max_message);
         display_decimal(axis_max);
         UART_tx('\r');
         UART_tx_str(str_message);
         display_decimal(att_strength);
      }
      else if( uart_rx_data == 'y' ) {
         UART_tx_str(axis_message);
         for(i=0 ; i<10 ; i++)
            display_decimal(Y_dat[i]);
         axis_max = find_maximum(Y_dat);
         UART_tx('\r');
         UART_tx_str(max_message);
         display_decimal(axis_max);
         UART_tx('\r');
         UART_tx_str(str_message);
         display_decimal(att_strength);
      }
      UART_tx('\r');
      UART_tx('\r');
      uart_rx_data = -1;
      axis_max = 0;
      att_strength = 0;
   }
}

/****************************************
 *   
 *                  SPI
 *                Routines
 *   
 ****************************************/

/*
 *  Toggles chip select and loads data to SPI.
 *  Not useful on its own.
*/
void SPI_tx(char data) {
   CHIP_SEL = 0;
   SSPBUF = data;
   pause();
   CHIP_SEL = 1;
}

/* 
 * Sends a register address to the accelerometer and
 * subsequently receives its contents
*/
char acc_read(char reg) {
   char temp;

   // Clear buffer
   temp = SSPBUF;
   reg |= 0x80;
   // Transmit register address packet
   SPI_tx(reg);
   while(!SSPSTATbits.BF);
   // Read garbage packet
   temp = SSPBUF;
   // Send garbage packet to receive register data
   SPI_tx(0x30);
   spi_rx_data = SSPBUF;

   return spi_rx_data;
}

/* 
 * Sends two packets of data to the accelerometer to
 * write to a configuration register.
 * 1.  reg address
 * 2.  reg data
 */
void acc_config(char reg, char input) {
   char temp;
   // Initialize
   temp = SSPBUF;
   CHIP_SEL = 0;
   PIR1bits.SSPIF = 0;
   SSPCON1bits.WCOL = 0;
   // Transmit register address packet
   SSPBUF = reg;                 // Load
   pause();
   temp = SSPBUF;                // Dump
   // Transmit register data packet
   SSPBUF = input;               // Load
   pause();
   temp = SSPBUF;                // Dump
   // Finalize
   CHIP_SEL = 1;
}

//--> Method to transmit through SPI
void test_SPI() {
   while(1) {
      //SPI_tx(0x55);    // _-_-_-_- //
      SPI_tx(0x6A);      // _--_-_-_ //
      //SPI_tx(0x7E);    // _------_ //
      pause();
   }
}

//--> Method to read in accelerometer device ID
void test_accelerometer() {
   char request[23] = "Requested device ID...";
   char receive[17] = "Received packet:";
   char buff[8] = "Buffer:";

   while(1) {
      delay_ms(50000);
      UART_tx_str(request);
      acc_read(0x32);             //Request X0 data
      UART_tx_str(receive);
      UART_tx(spi_rx_data);       //Print result
      UART_tx('\r');
      UART_tx('\r');
      spi_rx_data = 0;
   }
}

/****************************************
 *   
 *                  UART
 *                Routines
 *   
 ****************************************/

/*
 *  Sends a byte through UART
*/
void UART_tx(char dat) {
   while (PIR1bits.TXIF == 0) ;
   TXREG = dat;
}

/*
 *  Transmits a string through UART
*/
void UART_tx_str(char message[50]) {
   int index = 0;
   while( message[index] != '\0' ) {
      UART_tx( message[index] );
      index++;
   }
   UART_tx('\r');
}

/*
 *  ISR:  Receives a byte through UART
*/
void UART_rx() {
   uart_rx_data = RCREG;
   didReceive_uart = 1;
}


/*
 *  Can be configured to test Tx or Rx with UART.
 *  Tx transmits "Hello World" and Rx parrots a character back
*/
void test_UART() {
   char message[12] = "Hello World";
   char method = 0;  // 0=Tx , 1=Rx
   int i;
   while(1) {
      if(method == 1 && didReceive_uart == 1) {
         for ( i=0 ; i<5 ; i++)
            UART_tx(uart_rx_data);
         UART_tx('\r');
         didReceive_uart = 0;
      }
      else if (method == 0) { 
         for( i=0 ; i<11 ; i++ )
            UART_tx( message[i] );
         UART_tx('\r');
      }
   }
}

/****************************************
 *   
 *             Ammo & Visual
 *               Routines
 *   
 ****************************************/

//--> Timer3 overflow ISR to scroll the 4 strength gauge LEDs
void update_strength_gauge() {
   //--> Handle a gauge overflow if latency has passed
   if ( t3_ovf == STRENGTH_GAUGE_LATENCY ) {
      // Reset overflow counter
      t3_ovf = 0;
     // Update strength LEDs
      if ( gauge_index <= att_strength ) {
         switch (gauge_index) {
          case 0:
               PORTA &= ~STREN; break;
            case 1:
               PORTA |= 0x01;   break;
          case 2:
               PORTA |= 0x03;   break;
          case 3:
               PORTA |= 0x07;   break;
          case 4:
               PORTA |= 0x0F;   break;
       }
         gauge_index++;  //Attacking should reset index
      }
   }
   //--> Increase number of overflows otherwise
   else
      t3_ovf++;
}

//--> Timer1 overflow ISR to track time since successful action
void update_cooldown() {
   // Attack cooldown
   if ( !att_rdy ) {
      if ( t1_ovf_att==COOLDOWN ) {
       // Reset attack variables
         att_rdy = 1;
         t1_ovf_att = 0;
       //**att_strength = 0;
       gauge_index = 0;
      }
      else
         t1_ovf_att++;
   }
   // Reload cooldown
   if ( !rld_rdy) {
      if ( t1_ovf_rld==COOLDOWN ) {
         rld_rdy = 1;
         t1_ovf_rld = 0;
      }
      else
         t1_ovf_rld++;
   }
}

//--> Routine to increase/decrease ammo and write to 7-S display
void update_ammo(char amount) {
   char code;
   // Numeric handling
   if ( (amount==-1) && (current_ammo>0) )
      current_ammo--;
   else if ( (amount==1) && (current_ammo<MAX_AMMO) )
      current_ammo++;
   else if (amount == MAX_AMMO)
      current_ammo = MAX_AMMO;
   else if (amount == 0)
      current_ammo = 0;
   // 7-Segment handling
   code = (current_ammo << 4);   //Move binary ammo to upple nibble
   PORTD &= ~SEGMENT;            //Clear 7S display
   PORTD |= code;                //Output binary number
}

//--> Method to read external switches that activate RLD and ATT cooldowns
void test_cooldown() {
   // Attack:  check RD2 for a pressed switch
   if ( DUMB2==1 && att_rdy && current_ammo>0 ) {
      att_rdy = 0;
      PORTDbits.RD0 = 0;   //Turn off an LED on R0
     update_ammo(-1);
   }
   else if (att_rdy)
      PORTDbits.RD0 = 1;   //Turn on RD0 LED
   // Reload: check RD3 for a pressed switch
   if ( DUMB3==1 && rld_rdy && current_ammo<=MAX_AMMO ) {
      rld_rdy = 0;
      PORTDbits.RD1 = 0;   //Turn off an LED on R1
     update_ammo(1);
   }
   else if (rld_rdy)
      PORTDbits.RD1 = 1;   //Turn on RD1 LED
}

/****************************************
 *   
 *              Auxilliary
 *               Routines
 *   
 ****************************************/

//--> Halts program execution for a number of milliseconds
void delay_ms(int milli) {
   const int CYC_PER_MS = 8000;
   long delay = (CYC_PER_MS * milli);     // Number of instructions
   long i;
   for (i=0 ; i<delay ; i++);
}

//--> Halts program execution for a number of cycles
void pause() {
   int i;
   for(i=0 ; i<64 ; i++);
}

//--> Changes a binary number to ascii so it can be printed with UART
void display_decimal(int number) {
	int j=0;
    int value[5];
    char isNegative = 0;

    if(number < 0) {
        number = ~number + 1;
        isNegative = 1;
    }

    if(number>=10000) {          //Ten-Thousand's place
        j = number / 10000;
        value[0] = j + 48;
        number = number % 10000;
    }
    else
        value[0] = '0';
    if(number>=1000) {           //Thousand's place
        j = number / 1000;
        value[1] = j + 48;
        number = number % 1000;
    }
    else
        value[1] = '0';
	if(number>=100) {             //Hundred's place
		j = number / 100;
		value[2]= j + 48;         //ASCII offset
		number = number % 100;
	}
	else
		value[2]= '0';
	if(number>=10) {             //Ten's place
		j = number / 10;
		value[3]= j + 48;         //ASCII offset
		number 	= number % 10;
	}
	else
		value[3]= '0';
	value[4] 	= number + 48;     //One's place

   //Print to UART
   if(isNegative)
      UART_tx('-');
   if(value[0] != '0')
      UART_tx(value[1]);
   if(value[1] != '0')
      UART_tx(value[1]);
   if(value[2] != '0')
      UART_tx(value[2]);
   if(value[3] != '0')
      UART_tx(value[3]);
   UART_tx(value[4]);
   UART_tx(' ');
}


/****************************************
 *   
 *           Initialization
 *              Methods
 *   
 ****************************************/
void init_all() {
   init_port_directions();
   init_oscillator();
   init_interrupts();
   init_timers();
   init_SPI();
   init_SPI_std();
   init_UART();
   init_accelerometer();
   init_PWM();
}

void init_port_directions() {
   // 0 = output //
   // 1 = input  //

   //--> Strength LEDs
   TRISAbits.TRISA0 = 0;
   TRISAbits.TRISA1 = 0;
   TRISAbits.TRISA2 = 0;
   TRISAbits.TRISA3 = 0;
   //--> Audio Selectors
   TRISAbits.TRISA4 = 0;
   TRISAbits.TRISA5 = 0;
   TRISAbits.TRISA6 = 0;
   TRISAbits.TRISA7 = 0;

   //--> IR Selectors
   TRISBbits.TRISB0 = 0;
   TRISBbits.TRISB1 = 0;
   //--> IR-Tx and IR-Rx
   TRISBbits.TRISB2 = 1;
   TRISBbits.TRISB3 = 0;
   //--> Ready LED
   TRISBbits.TRISB4 = 0;
   //--> Programming pins (arbitrary)
   TRISBbits.TRISB5 = 1;
   TRISBbits.TRISB6 = 1;
   TRISBbits.TRISB7 = 1;

   //--> Reload switch
   TRISCbits.TRISC0 = 1;
   //--> Dummy pin
   TRISCbits.TRISC1 = 1;
   //--> Chip select
   TRISCbits.TRISC2 = 0;
   //--> SPI pins
   TRISCbits.TRISC3 = 0;  //SCK
   TRISCbits.TRISC4 = 1;  //SDI
   TRISCbits.TRISC5 = 0;  //SD0
   //--> UART
   TRISCbits.TRISC6 = 1;  //Tx
   TRISCbits.TRISC7 = 1;  //Rx specified in datasheet

   //--> Dummy Pins
   TRISDbits.TRISD0 = 0;  //Attack LED
   TRISDbits.TRISD1 = 0;  //Reload LED
   TRISDbits.TRISD2 = 1;  //Attack switch
   TRISDbits.TRISD3 = 1;  //Reload switch
   //--> 7-Segment
   TRISDbits.TRISD4 = 0;
   TRISDbits.TRISD5 = 0;
   TRISDbits.TRISD6 = 0;
   TRISDbits.TRISD7 = 0;
}

void init_oscillator() {
   OSCCON &= ~0x03;               //Choose primary oscillator
   OSCTUNEbits.PLLEN = 1;         //Enable PLL multiplier
   OSCCON |= 0x70;                //Set to 8 MHz
}

void init_interrupts() {
   //--> Enable all interrupt handling
   RCONbits.IPEN = 1;       //Enable interrupt priorities
   INTCONbits.GIEH = 1;     //Enable high-priority interrupts
   INTCONbits.PEIE = 1;     //Enable low-priority interrupts
   //--> IR-Rx external interrupt pin
   INTCON3bits.INT2IE = 1;   //Enables external on RB2
   INTCON3bits.INT2IP = 1;   //Sets to High priority
   INTCON2bits.INTEDG2 = 0;  //Falling edge triggered
}

void init_timers() {
   //--> Timer 1
   T1CONbits.TMR1ON = 1;    //Enable Timer 1
   T1CONbits.RD16 = 1;      //Choose 16-bit
   T1CON &= ~0x30;          //Set a 1:8 prescalar
   T1CONbits.TMR1CS = 0;    //Uses clock of Fosc/4
   PIE1bits.TMR1IE = 1;     //Enables overflow interrupt
   IPR1bits.TMR1IP = 0;     //Set to low priority
   //--> Timer 3
   T3CONbits.TMR3ON = 1;    //Enable Timer 3
   T3CONbits.RD16 = 1;      //Choose 16-bit
   T3CON &= ~0xF0;           //Set a 1:1 prescalar
   T3CONbits.TMR3CS = 0;    //Uses clock of Fosc/4
   PIE2bits.TMR3IE = 1;     //Enables overflow interrupt
   IPR2bits.TMR3IP = 0;     //Set to low priority
}

void init_SPI() {
   PORTCbits.RC2 = 1;        //Set Chip Select pin high
   SSPCON1bits.SSPEN = 1;    //Enable serial ports
   SSPCON1 &= ~0x0F;       //Set SCK at Fosc/4
   SSPCON1bits.CKP = 1;      //SCK idles high
   SSPSTATbits.CKE = 0;      //Data transmitted on rising edge
   SSPSTATbits.SMP = 1;      //Data sampled on falling edge
   //**PIE1bits.SSPIE = 1;       //Enable SSPBUF interrupt
   //**IPR1bits.SSPIP = 0;       //Set low priority
}

void init_SPI_std() {

}

void init_UART() {
   RCSTAbits.SPEN = 1;      //Enable RC6:7 as serial ports
   RCSTAbits.RX9 = 0;       //Set 8-bit packets
   TXSTAbits.TXEN = 1;      //Enable Tx
   RCSTAbits.CREN = 1;      //Enable Rx
   TXSTAbits.SYNC = 0;      //Set asychronous
   BAUDCONbits.TXCKP = 0;   //Tx idle (1=high)
   BAUDCONbits.RXDTP = 0;   //Rx idle (1=high)
   SPBRG = 12;              //Set a 9600 baud rate
   SPBRGH = 0;              //  --
   PIE1bits.RCIE = 1;       //Enable interrupt on receive
   IPR1bits.RCIP = 0;       //Set low priority
}

void init_accelerometer() {
   acc_config(THRESH_TAP, 0x38);
   acc_config(DUR, 0x10);
   acc_config(LATENT, 0x50);
   acc_config(WINDOW, 0xFF);
//   acc_config(THRESH_ACT, 0x30);
//  acc_config(THRESH_INACT, 0);
//   acc_config(TIME_INACT, 0);
//   acc_config(ACT_INACT_CTL, 0x70);
//   acc_config(THRESH_FF, 0);
//   acc_config(TIME_FF, 0);
   acc_config(TAP_AXES, 0x01);
//   acc_config(BW_RATE, 0x0F);         //Set max transfer rate
   acc_config(POWER_CTL, 0x08);       //Turn off standby
   acc_config(INT_ENABLE, 0xE0);      //Enable double tap
   acc_config(INT_MAP, 0x9F);         //Interrupt on INT1 pin
   acc_config(DATA_FORMAT, 0x01);     //Set resolution and big-endian
//   acc_config(FIFO_CTL, 0x9D);        //30 samples for watermark
}

void init_PWM() {

}


/****************************************
 *   
 *              Interrupt
 *              Routines
 *   
 ****************************************/

#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void) {
  _asm
     goto InterruptServiceHigh  //jump to interrupt routine
  _endasm
}

#pragma code InterruptVectorLow = 0x18
void InterruptVectorLow (void) {
  _asm
     goto InterruptServiceLow  //jump to interrupt routine
  _endasm
}

#pragma interrupt InterruptServiceHigh
void InterruptServiceHigh() {
   if (1) {     //********Check something********
   }
}

#pragma interrupt InterruptServiceLow
void InterruptServiceLow() {
   //--> Check Timer 1 interrupt flag
   if (PIR1bits.TMR1IF) {
      update_cooldown();
      if( LED_toggle == 0 ) {
         READY = 1;
         LED_toggle = 1;
      }
      else {
         READY = 0;
         LED_toggle = 0;
      }
      PIR1bits.TMR1IF = 0;      //Clear interrupt flag
   }
   //--> Check Timer 3 interrupt flag
   if (PIR2bits.TMR3IF) {     
      update_strength_gauge();
      PIR2bits.TMR3IF = 0;      //Clear interrupt flag
   }
   //--> Check for UART receive
   if (PIR1bits.RCIF) {
      UART_rx();
   }
}

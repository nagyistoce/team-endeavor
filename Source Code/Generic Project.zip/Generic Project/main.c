#define GENERIC_PROJECT 404
#define MODEL 18F4520

void main() {
   while(1);
}